<?php include('include/config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home</title>
<link href="css/styleNew.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/jquery.js"></script>
<link rel="stylesheet" href="css/pop_up.css"type="text/css" media="screen" />
<script src="js/pop_up.js" type="text/javascript"></script>

<script type="text/javascript">
function searchImages()
{
	var Item=$('#SearchBox').val();
	if(Item=='Enter image name you want to search...' || Item=='')
	{
		alert('Please enter valid Search');
		return false;
	}
	else
	{
	document.location.href="<?php echo HTTP_PATH; ?>index.php?Item="+Item;
    }
}
function AddFavorite()
{
	var img=$('#img').html();
	var title=$('#title1').val();
	var content=$('#content1').val();
	var width=$('#width1').val();
	var height=$('#height1').val();
	var tbwidth=$('#tbwidth1').val();
	var tbheight=$('#tbheight1').val();
	var UnUrl=$('#UnUrl1').val();
	var Url=$('#Url1').val();
	var VUrl=$('#VUrl1').val();
	var TNFrmt=$('#TNFrmt1').val();
	var OCUrl=$('#OCUrl1').val();
	var tbUrl=$('#tbUrl1').val();
	var imageId=$('#imageId1').val();
	var CNFrmt=$('#CNFrmt1').val();
	
	$.ajax({
  url: '<?php echo HTTP_PATH; ?>FavoritesSave.php?title='+title+'&content='+content+'&width='+width+'&height='+height+'&tbwidth='+tbwidth+'&tbheight='+tbheight+'&UnUrl='+UnUrl+'&Url='+Url+'&VUrl='+VUrl+'&TNFrmt='+TNFrmt+'&OCUrl='+OCUrl+'&tbUrl='+tbUrl+'&imageId='+imageId+'&CNFrmt='+CNFrmt+'&image='+img+'&action=Add',
  context:document.body,
  success: function(data) {
         if(data=='true')
		 {
			 $('#notview').css('display','none');
			 $('#views').css('display','block');
			 $('#views').html('<p  style="color:#060; font-family:Comic Sans MS, cursive; font-size: 16px;margin-left: 35px;margin-top: 23px;">You have successfully added this Image to your Favorite list</p>');
		 }
                          }
      });
}

function DeleteFav(id)
{
	var con=confirm('Do you really want to delete this image');
	if(con){
$.ajax({
  url: '<?php echo HTTP_PATH; ?>FavoritesSave.php?id='+id+'&action=Delete',
  context:document.body,
  success: function(data) {
         if(data=='true')
		 {
			 location.reload();
		 }
                          }
      });	
	}
}
function addDesc(id,i)
{
	desc=$('#des'+i).val();
	$.ajax({
  url: '<?php echo HTTP_PATH; ?>FavoritesSave.php?id='+id+'&desc='+desc+'&action=AddDesc',
  context:document.body,
  success: function(data) {
         if(data=='true')
		 {
			 $('#des'+i).val('');
			 location.reload();
		 }
                          }
      });	
}

function DeleteDesc(id)
{
	$.ajax({
  url: '<?php echo HTTP_PATH; ?>FavoritesSave.php?id='+id+'&action=DelDesc',
  context:document.body,
  success: function(data) {
         if(data=='true')
		 {
			 
			 location.reload();
		 }
                          }
      });	
	
}
function ShowDes(i)
{
	$('#btnDiv'+i).css('display','none');
	$('#desDiv'+i).css('display','block');
	$('#descptn'+i).css('display','none');
	$('#adddescptn'+i).css('display','block');
}
</script>

</head>

<body>

	<!--start wraper div here-->
		<div id="wraper">
        
        
        <!--start header div here-->
        
        <div class="header">
        <div class="logo_cont">
        <div class="logo"><a href="<?php echo HTTP_PATH; ?>"><img src="images/logo.png" alt="" width="266" height="66" border="0" /></a></div>
        <div class="search_cont">
       <input type="text" value="Enter image name you want to search..." onfocus="if(this.value=='Enter image name you want to search...'){this.value='';}" onblur="if(this.value==''){this.value='Enter image name you want to search...';}" class="search_input" name="SearchBox" id="SearchBox">
        <div class="search_btn"><a href="#" onclick="searchImages();"><img src="images/search_btn.png" alt="" width="89" height="33" border="0" /></a></div>
        </div>
        </div>
        
        <div class="text_heading">
        <p><a href="<?php echo HTTP_PATH; ?>FavoritesList.php">See Favorites</a></p>
        </div>
        
        
        </div>
        
       <!--close header div here-->
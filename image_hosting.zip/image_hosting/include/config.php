<?php 
define("ROOT_FOLDER", 'image_hosting');
define("HTTP_PATH", 'http://'.$_SERVER['HTTP_HOST'].'/'.ROOT_FOLDER.'/');
define("HTTP_PATHS", 'https://'.$_SERVER['HTTP_HOST'].'/'.ROOT_FOLDER.'/' );
define("ROOT_PATH", $_SERVER['DOCUMENT_ROOT'].'/'.ROOT_FOLDER.'/');



?>
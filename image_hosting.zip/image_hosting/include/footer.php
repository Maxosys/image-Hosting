 <div class="footer">
 	<div class="inner_footer">
    <p>Copyright ©2013-2014 imagehosting. Powered by : Nano web tech</p>
    </div>
 		
 
    </div>
    
    
</body>
</html>

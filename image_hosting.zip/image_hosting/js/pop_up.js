/***************************/
//@Author: Adrian "yEnS" Mato Gondelle
//@website: www.yensdesign.com
//@email: yensamg@gmail.com
//@license: Feel free to use it, but keep this credits please!					
/***************************/

//SETTING UP OUR POPUP
//0 means disabled; 1 means enabled;
var popupStatus = 0;

//loading popup with jQuery magic!
function loadPopup(){
	//loads popup only if it is disabled
	if(popupStatus==0){
		$("#backgroundPopup").css({
			"opacity": "0.7"
		});
		$("#backgroundPopup").fadeIn("slow");
		$("#popupContact").fadeIn("slow");
		popupStatus = 1;
	}
}

//disabling popup with jQuery magic!
function disablePopup(){
	//disables popup only if it is enabled
	if(popupStatus==1){
		$("#backgroundPopup").fadeOut("slow");
		$("#popupContact").fadeOut("slow");
		popupStatus = 0;
	}
}

//centering popup
function centerPopup(){
	//request data for centering
	var windowWidth = document.documentElement.clientWidth;
	var windowHeight = document.documentElement.clientHeight;
	var popupHeight = $("#popupContact").height();
	var popupWidth = $("#popupContact").width();
	//centering
	$("#popupContact").css({
		"position": "absolute",
		"top": windowHeight/2-popupHeight/2,
		"left": windowWidth/2-popupWidth/2
	});
	//only need force for IE6
	
	$("#backgroundPopup").css({
		"height": windowHeight
	});
	
}


//CONTROLLING EVENTS IN jQuery
//$(document).ready(function(){
	function OpenPopup(i) {
	//LOADING POPUP
	
	var img=$('#img'+i).val();
	var title=$('#title'+i).val();
	var content=$('#content'+i).val();
	var width=$('#width'+i).val();
	var height=$('#height'+i).val();
	var tbwidth=$('#tbwidth'+i).val();
	var tbheight=$('#tbheight'+i).val();
	var UnUrl=$('#UnUrl'+i).val();
	var Url=$('#Url'+i).val();
	var VUrl=$('#VUrl'+i).val();
	var TNFrmt=$('#TNFrmt'+i).val();
	var OCUrl=$('#OCUrl'+i).val();
	var tbUrl=$('#tbUrl'+i).val();
	var imageId=$('#imageId'+i).val();
	var CNFrmt=$('#CNFrmt'+i).val();
	//alert(imageId);
	/*alert(img);
	alert(title);
	alert(content);
	alert(width);
	alert(height);
	alert(tbwidth);
	alert(tbheight);
	alert(UnUrl);
	alert(Url);
	alert(VUrl);
	alert(TNFrmt);
	alert(OCUrl);*/
	$('#img').html('<img src="'+tbUrl+'" alt="" width="200" height="113" border="0" style="margin-left:140px"/>');
	$('#title').html(title);
	$('#content').html(content);
	$('#width').html(width);
	$('#height').html(height);
	$('#tbwidth').html(tbwidth);
	$('#tbheight').html(tbheight);
	$('#UnUrl').html(UnUrl);
	$('#Url').html(Url);
	$('#VUrl').html(VUrl);
	$('#TNFrmt').html(TNFrmt);
	$('#OCUrl').html(OCUrl);
	$('#title1').val(title);
	$('#content1').val(content);
	$('#width1').val(width);
	$('#height1').val(height);
	$('#tbwidth1').val(tbwidth);
	$('#tbheight1').val(tbheight);
	$('#UnUrl1').val(UnUrl);
	$('#Url1').val(Url);
	$('#VUrl1').val(VUrl);
	$('#TNFrmt1').val(TNFrmt);
	$('#OCUrl1').val(OCUrl);
	$('#tbUrl1').val(tbUrl);
	$('#imageId1').val(imageId);
	$('#CNFrmt1').val(CNFrmt);
		//centering with css
		centerPopup();
		//load popup
		loadPopup();
	//});
	

	
				
	//CLOSING POPUP
	//Click the x event!
	$("#popupContactClose").click(function(){
		$('#views').css('display','none');
		$('#notview').css('display','block');
		disablePopup();
	});
	//Click out event!
	$("#backgroundPopup").click(function(){
		disablePopup();
	});
	//Press Escape event!
	$(document).keypress(function(e){
		if(e.keyCode==27 && popupStatus==1){
			disablePopup();
		}
	});

};



<?php 
include('connection.php');
if(isset($_REQUEST['action']) && $_REQUEST['action']=='Add')
{
	
	$query=mysql_query('INSERT INTO `user_favourites`(`IP_Address`, `imageId`, `title`, `content`, `width`, `height`, `tbWidth`, `tbHeight`, `unescapedUrl`, `url`, `visibleUrl`, `titleNoFormatting`, `originalContextUrl`, `contentNoFormatting`, `tbUrl`, `added`) VALUES ("'.$_SERVER['REMOTE_ADDR'].'","'.$_REQUEST['imageId'].'","'.$_REQUEST['title'].'","'.$_REQUEST['content'].'","'.$_REQUEST['width'].'","'.$_REQUEST['height'].'","'.$_REQUEST['tbwidth'].'","'.$_REQUEST['tbheight'].'","'.$_REQUEST['UnUrl'].'","'.$_REQUEST['Url'].'","'.$_REQUEST['VUrl'].'","'.$_REQUEST['TNFrmt'].'","'.$_REQUEST['OCUrl'].'","'.$_REQUEST['CNFrmt'].'","'.$_REQUEST['tbUrl'].'",now())');

if($query)
{
echo "true";	
}
else
{
echo "false";
}
}
if(isset($_REQUEST['action']) && $_REQUEST['action']=='Delete')
{
	$query=mysql_query('DELETE FROM `user_favourites` WHERE id="'.$_REQUEST['id'].'"');
	if($query)
{
echo "true";	
}
else
{
echo "false";
}
}
if(isset($_REQUEST['action']) && $_REQUEST['action']=='AddDesc')
{
	$query=mysql_query('UPDATE `user_favourites` SET `description`="'.$_REQUEST['desc'].'" WHERE id="'.$_REQUEST['id'].'"');
	if($query)
{
echo "true";	
}
else
{
echo "false";
}
}

if(isset($_REQUEST['action']) && $_REQUEST['action']=='DelDesc')
{
	$query=mysql_query('UPDATE `user_favourites` SET `description`="" WHERE id="'.$_REQUEST['id'].'"');
	if($query)
{
echo "true";	
}
else
{
echo "false";
}
}
?>
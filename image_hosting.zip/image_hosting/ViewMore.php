<div id="popupContact">
		<a id="popupContactClose"></a>
		<h1>View More</h1>
        
	<div class="thumb_cont">

<div class="one_thumb_pop">
<div id="views"></div>
<div id="notview">
<span id="img"></span>
  <div class="one_thumb_title_pop">
  <h3>Title	:</h3>
  <h4 id="title">
  
   </h4>
  </div>
  
  <div class="one_thumb_title_pop">
  <h3>Content :</h3>
  <h4 id="content">
 
   </h4>
  </div>
  
  <div class="one_thumb_title_pop">
  <h3>Width :</h3>
   <h4 id="width"></h4>
  </div>
  <div class="one_thumb_title_pop">
  <h3>Height :</h3>
   <h4 id="height"></h4>
  </div>
  <div class="one_thumb_title_pop">
  <h3>Url :</h3>
  <h4 id="Url">

   </h4>
  </div>
  <div class="one_thumb_title_pop">
  <h3>Visible Url :</h3>
  <h4 id="VUrl">
  
   </h4>
  </div>
  <div class="one_thumb_title_pop">
  <h3>Title No Formatting :</h3>
  <h4 id="TNFrmt">
 
   </h4>
  </div>
  
   <div class="one_thumb_title_pop">
  <h3>Original Context Url :</h3>
  <h4 id="OCUrl"> 
  
   </h4>
  </div>
<input type="hidden" id="img1" value="" />
<input type="hidden" id="title1" value="" />
<input type="hidden"  id="content1" value="" />
<input type="hidden" id="width1" value="" />
<input type="hidden" id="height1" value="" />
<input type="hidden" id="tbwidth1" value="" />
<input type="hidden" id="tbheigh1t" value="" />
<input type="hidden" id="UnUrl1" value="" />
<input type="hidden" id="Url1" value="" />
<input type="hidden" id="VUrl1" value="" />
<input type="hidden" id="TNFrmt1" value="" />
<input type="hidden" id="OCUrl1" value="" />
<input type="hidden" id="CNFrmt1" value="" />
<input type="hidden" id="tbUrl1" value="" />
<input type="hidden" id="imageId1" value="" />
<input type="hidden" id="CNFrmt1" value="" />
  <div class="clear"></div>
  
  <div class="fav_btn_pop"><a id="my-button" href="#" onClick="AddFavorite();">Add To Favorties</a></div>
  
  </div>
  </div>
  
</div>
	</div>
    
    <div id="backgroundPopup"></div>

<?php $pageName='homepage' ?>
<?php include('ImageClass/getImages.php')?>
<?php include('include/header.php'); ?>

<div class="content_cont">
       <h1>Welcome User</h1>
       <p>These images are fetched from Google Images.By default it fetch Red Roses images. <br />
<br />


If you search images of your choice ,please enter image you want to search and hit search button.<br />
<br />



<div class="clear"></div>

<?php $i=1;  ?>
<?php foreach($images as $row=>$val) {   ?>
<input type="hidden" id="img<?php echo $row; ?>" value="<?php echo $val['tbUrl'] ?>" />
<input type="hidden" id="title<?php echo $row; ?>" value="<?php echo $val['title'] ?>" />
<input type="hidden"  id="content<?php echo $row; ?>" value="<?php echo $val['content'] ?>" />
<input type="hidden" id="width<?php echo $row; ?>" value="<?php echo $val['width'] ?>" />
<input type="hidden" id="height<?php echo $row; ?>" value="<?php echo $val['height'] ?>" />
<input type="hidden" id="tbwidth<?php echo $row; ?>" value="<?php echo $val['tbWidth'] ?>" />
<input type="hidden" id="tbheight<?php echo $row; ?>" value="<?php echo $val['tbHeight'] ?>" />
<input type="hidden" id="UnUrl<?php echo $row; ?>" value="<?php echo $val['unescapedUrl'] ?>" />
<input type="hidden" id="Url<?php echo $row; ?>" value="<?php echo $val['url'] ?>" />
<input type="hidden" id="VUrl<?php echo $row; ?>" value="<?php echo $val['visibleUrl'] ?>" />
<input type="hidden" id="TNFrmt<?php echo $row; ?>" value="<?php echo $val['titleNoFormatting'] ?>" />
<input type="hidden" id="OCUrl<?php echo $row; ?>" value="<?php echo $val['originalContextUrl'] ?>" />
<input type="hidden" id="CNFrmt<?php echo $row; ?>" value="<?php echo $val['contentNoFormatting'] ?>" />
<input type="hidden" id="tbUrl<?php echo $row; ?>" value="<?php echo $val['tbUrl'] ?>" />
<input type="hidden" id="imageId<?php echo $row; ?>" value="<?php echo $val['imageId'] ?>" />
<?php if($i==1) { ?>
<div class="thumb_cont">
<?php } ?>
<?php if($i<3) {?>
<div class="one_thumb">


  <!--<img src="<?php //echo $val['tbUrl'] ?>" alt="" width="150" height="113" border="0" />-->
  <div class="one_thumb_title">
  <h3>Title	:</h3>
  <h4>
  <?php if(strlen($val['title'])>30) {?>
  <?php echo substr($val['title'],0,30).'...' ?>
  <?php } else {?>
   <?php echo $val['title']; ?>
   <?php } ?>
   </h4>
  </div>
  <div class="one_thumb_title">
  <h3>Image Id :</h3>
  <h4>
  <?php if(strlen($val['imageId'])>25) {?>
  <?php echo substr($val['imageId'],0,25).'...' ?>
  <?php } else {?>
   <?php echo $val['imageId']; ?>
   <?php } ?>
   </h4>
  </div>
  <div class="one_thumb_title">
  <h3>Content :</h3>
  <h4>
  <?php if(strlen($val['content'])>50) {?>
  <?php echo substr($val['content'],0,50).'...' ?>
  <?php } else {?>
   <?php echo $val['content']; ?>
   <?php } ?>
   </h4>
  </div>
  
  <div class="one_thumb_title">
  <h3>Content No Formatting :</h3>
  <h4>
  <?php if(strlen($val['contentNoFormatting'])>50) {?>
  <?php echo substr($val['contentNoFormatting'],0,50).'...' ?>
  <?php } else {?>
   <?php echo $val['contentNoFormatting']; ?>
   <?php } ?>
   </h4>
  </div>
  
  <div class="one_thumb_title">
  <h3>Width :</h3>
   <h4><?php echo $val['width']; ?></h4>
  </div>
  <div class="one_thumb_title">
  <h3>Height :</h3>
   <h4 id="height<?php echo $row; ?>"><?php echo $val['height']; ?></h4>
  </div>
  <div class="one_thumb_title">
  <h3>tbWidth :</h3>
   <h4 id="tbwidth<?php echo $row; ?>"><?php echo $val['tbWidth']; ?></h4>
  </div>
  <div class="one_thumb_title">
  <h3>tbHeight :</h3>
   <h4 id="tbheight<?php echo $row; ?>"><?php echo $val['tbHeight']; ?></h4>
  </div>
  <div class="one_thumb_title">
  <h3>tbUrl :</h3>
  <h4>
  <?php if(strlen($val['tbUrl'])>50) {?>
  <?php echo substr($val['tbUrl'],0,50).'...' ?>
  <?php } else {?>
   <?php echo $val['tbUrl']; ?>
   <?php } ?>
   </h4>
  </div>
  <div class="one_thumb_title">
  <h3>Unescaped Url :</h3>
  <h4 id="UnUrl<?php echo $row; ?>">
  <?php if(strlen($val['unescapedUrl'])>25) {?>
  <?php echo substr($val['unescapedUrl'],0,25).'...' ?>
  <?php } else {?>
   <?php echo $val['unescapedUrl']; ?>
   <?php } ?>
   </h4>
  </div>
  <div class="one_thumb_title">
  <h3>Url :</h3>
  <h4 id="Url<?php echo $row; ?>">
  <?php if(strlen($val['url'])>25) {?>
  <?php echo substr($val['url'],0,25).'...' ?>
  <?php } else {?>
   <?php echo $val['url']; ?>
   <?php } ?>
   </h4>
  </div>
  <div class="one_thumb_title">
  <h3>Visible Url :</h3>
  <h4 id="VUrl<?php echo $row; ?>">
  <?php if(strlen($val['visibleUrl'])>25) {?>
  <?php echo substr($val['visibleUrl'],0,25).'...' ?>
  <?php } else {?>
  <?php echo $val['visibleUrl']; ?>
   <?php } ?>
   </h4>
  </div>
  <div class="one_thumb_title">
  <h3>Title No Formatting :</h3>
  <h4 id="TNFrmt<?php echo $row; ?>">
  <?php if(strlen($val['titleNoFormatting'])>30) {?>
  <?php echo substr($val['titleNoFormatting'],0,30).'...' ?>
  <?php } else {?>
  <?php echo $val['titleNoFormatting']; ?>
   <?php } ?>
   </h4>
  </div>
  
   <div class="one_thumb_title">
  <h3>Original Context Url :</h3>
  <h4 id="OCUrl<?php echo $row; ?>"> 
  <?php if(strlen($val['originalContextUrl'])>25) {?>
 <?php echo substr($val['originalContextUrl'],0,25).'...' ?>
  <?php } else {?>
  <?php echo $val['originalContextUrl']; ?>
   <?php } ?>
   </h4>
  </div>
  <div class="clear"></div>
  
  <div class="fav_btn"><a id="my-button<?php echo $row ?>" href="#" onclick="OpenPopup(<?php echo $row; ?>);" >View More..</a></div>
  
  
  </div>
  <?php } else { ?>
  <div class="one_thumb pad-1">
 <input type="hidden" id="img<?php echo $row; ?>" value="<?php echo $val['tbUrl'] ?>" />
  <div class="one_thumb_title">
  <h3>Title	:</h3>
  <h4 id="title<?php echo $row; ?>">
  <?php if(strlen($val['title'])>30) {?>
  <?php echo substr($val['title'],0,30).'...' ?>
  <?php } else {?>
  <?php echo $val['title']; ?>
   <?php } ?>
   </h4>
  </div>
   <div class="one_thumb_title">
  <h3>Image Id :</h3>
  <h4>
  <?php if(strlen($val['imageId'])>25) {?>
  <?php echo substr($val['imageId'],0,25).'...' ?>
  <?php } else {?>
   <?php echo $val['imageId']; ?>
   <?php } ?>
   </h4>
  </div>
  <div class="one_thumb_title">
  <h3>Content :</h3>
  <h4 id="content<?php echo $row; ?>"> 
  <?php if(strlen($val['content'])>50) {?>
 <?php echo substr($val['content'],0,50).'...' ?>
  <?php } else {?>
  <?php echo $val['content']; ?>
   <?php } ?>
   </h4>
  </div>
  <div class="one_thumb_title">
   <h3>Content No Formatting :</h3>
  <h4>
  <?php if(strlen($val['contentNoFormatting'])>50) {?>
  <?php echo substr($val['contentNoFormatting'],0,50).'...' ?>
  <?php } else {?>
   <?php echo $val['contentNoFormatting']; ?>
   <?php } ?>
   </h4>
  </div>
  <div class="one_thumb_title">
  <h3>Width :</h3>
   <h4  id="width<?php echo $row; ?>"><?php echo $val['width']; ?></h4>
  </div>
  <div class="one_thumb_title">
  <h3>Height :</h3>
   <h4 id="height<?php echo $row; ?>"><?php echo $val['height']; ?></h4>
  </div>
  <div class="one_thumb_title">
  <h3>tbWidth :</h3>
   <h4 id="tbwidth<?php echo $row; ?>"><?php echo $val['tbWidth']; ?></h4>
  </div>
  <div class="one_thumb_title">
  <h3>tbHeight :</h3>
   <h4 id="tbheight<?php echo $row; ?>"><?php echo $val['tbHeight']; ?></h4>
  </div>
  <div class="one_thumb_title">
  <h3>tbUrl :</h3>
  <h4>
  <?php if(strlen($val['tbUrl'])>50) {?>
  <?php echo substr($val['tbUrl'],0,50).'...' ?>
  <?php } else {?>
   <?php echo $val['tbUrl']; ?>
   <?php } ?>
   </h4>
  </div>
  <div class="one_thumb_title">
  <h3>Unescaped Url :</h3>
  <h4 id="UnUrl<?php echo $row; ?>">
  <?php if(strlen($val['unescapedUrl'])>25) {?>
 <?php echo substr($val['unescapedUrl'],0,25).'...' ?>
  <?php } else {?>
  <?php echo $val['unescapedUrl']; ?>
   <?php } ?>
   </h4>
  </div>
  <div class="one_thumb_title">
  <h3>Url :</h3>
  <h4 id="Url<?php echo $row; ?>">
  <?php if(strlen($val['url'])>25) {?>
  <?php echo substr($val['url'],0,25).'...' ?>
  <?php } else {?>
  <?php echo $val['url']; ?>
   <?php } ?>
   </h4>
  </div>
  <div class="one_thumb_title">
  <h3>Visible Url :</h3>
  <h4 id="VUrl<?php echo $row; ?>">
  <?php if(strlen($val['visibleUrl'])>25) {?>
  <?php echo substr($val['visibleUrl'],0,25).'...' ?>
  <?php } else {?>
  <?php echo $val['visibleUrl']; ?>
   <?php } ?>
   </h4>
  </div>
  <div class="one_thumb_title">
  <h3>Title No Formatting :</h3>
  <h4 id="TNFrmt<?php echo $row; ?>">
  <?php if(strlen($val['titleNoFormatting'])>30) {?>
  <?php echo substr($val['titleNoFormatting'],0,30).'...' ?>
  <?php } else {?>
  <?php echo $val['titleNoFormatting']; ?>
   <?php } ?>
   </h4>
  </div>
  
   <div class="one_thumb_title">
  <h3>Original Context Url :</h3>
  <h4 id="OCUrl<?php echo $row; ?>"> 
  <?php if(strlen($val['originalContextUrl'])>25) {?>
 <?php echo substr($val['originalContextUrl'],0,25).'...' ?>
  <?php } else {?>
  <?php echo $val['originalContextUrl']; ?>
   <?php } ?>
   </h4>
  </div>
  <div class="clear"></div>
  
  <div class="fav_btn"><a id="my-button<?php echo $row ?>" href="#" onclick="OpenPopup(<?php echo $row ?>);" >View More..</a></div>
  
  
  </div>
  <?php } ?>
  
  <?php $i++; ?>
  
  
 <?php if($i==4) { ?>
 <?php  $i=1  ?>
</div>
<?php } ?>
<?php } ?>











       
       </div>
        <div class="clear"></div>
        </div>
       <?php include('ViewMore.php'); ?> 
	<!--close wraper div here-->
        <div class="clear"></div>
    
	<?php include('include/footer.php'); ?>
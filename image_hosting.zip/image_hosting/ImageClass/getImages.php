<?php
include("googleclass.php");
$gimage = new GoogleImages();
if(isset($pageName) && !isset($_REQUEST['Item']) &&$pageName=='homepage')
{
	$images=$gimage->get_images("red roses", 4, 5);
	
}
if(isset($pageName) && isset($_REQUEST['Item']) &&$pageName=='homepage')
{
	$images=$gimage->get_images($_REQUEST['Item'], 4, 5);
	
}
if(isset($pageName) && $pageName=='FavoritesList')
{
	include_once('connection.php');
	$query=mysql_query('select * from user_favourites where IP_Address="'.$_SERVER['REMOTE_ADDR'].'"');
	$result=array();
	
	while($row=mysql_fetch_assoc($query))
	{
	$result[]=$row;	
	}
	
}
?>
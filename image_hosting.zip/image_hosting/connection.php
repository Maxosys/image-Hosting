<?php 

$conn=mysql_connect('localhost','root','');
if(!$conn)
die("not connected");
mysql_select_db('image_hosting');

?>
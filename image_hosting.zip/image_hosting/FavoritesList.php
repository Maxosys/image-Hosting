<?php $pageName='FavoritesList' ?>
<?php include('ImageClass/getImages.php')?>
<?php include('include/header.php'); ?>

<div class="content_cont">
<?php if(!empty($result)) { ?>
<?php $i=1; ?>
<?php foreach($result as $key=>$val) {?>  
<?php if($i==1) { ?>     
<div class="thumb_cont">
<?php } ?>
<?php if($i<3) { ?>
<div class="one_thumb">


  <img src="<?php echo $val['tbUrl'] ?>" alt="" width="280" height="250" border="0" />
  <div><p style="margin-left:15px;" id="descptn<?php echo $key;?>"><?php if($val['description']=='') { echo "No description added"; } else {  echo $val['description'].' (<a href="javascript:;" style="text-decoration:none; color:black;" onclick="DeleteDesc('.$val['id'].')">delete description</a>)'; } ?></p>
  <p style="margin-left:15px; display:none;" id="adddescptn<?php echo $key;?>">Add Description</p>
  </div>
  <div class="clear"></div>
  <div id="desDiv<?php echo $key;?>" style="display:none"><p style="margin-left:20px;"><textarea id="des<?php echo $key;?>"></textarea></p><div class="fav_btn_fav"><a  href="javascript:;" onclick="addDesc(<?php echo $val['id']; ?>,<?php echo $key;?>)">Add</a></div>
  <div class="fav_btn_fav"><a  href="javascript:;" onclick="location.reload();" >Back</a></div></div>
  <div id="btnDiv<?php echo $key;?>">
  <div class="fav_btn_fav"><a id="delbutton<?php echo $key;?>" href="javascript:;" onclick="DeleteFav(<?php echo $val['id']?>);" >Delete</a></div>
  <div class="fav_btn_fav"><a id="desbutton<?php echo $key;?>" href="javascript:;" onclick="ShowDes(<?php echo $key;?>);" >Add Desctription</a></div>
  </div>
  
  </div>
  
  <?php } else {?>
  <div class="one_thumb pad-1">
   <img src="<?php echo $val['tbUrl'] ?>" alt="" width="280" height="250" border="0" />
  <div><p style="margin-left:15px;" id="descptn<?php echo $key;?>"><?php if($val['description']=='') { echo "No description added"; } else {  echo $val['description'].' (<a href="javascript:;" style="text-decoration:none; color:black;" onclick="DeleteDesc('.$val['id'].')">delete description</a>)'; } ?></p>
  <p style="margin-left:15px; display:none;" id="adddescptn<?php echo $key;?>">Add Description</p>
  </div>
  <div class="clear"></div>
  <div id="desDiv<?php echo $key;?>" style="display:none"><p style="margin-left:20px;"><textarea id="des<?php echo $key;?>" ></textarea></p><div class="fav_btn_fav"><a  href="javascript:;" onclick="addDesc(<?php echo $val['id']; ?>,<?php echo $key;?>)" >Add</a></div>
  <div class="fav_btn_fav"><a  href="javascript:;" onclick="location.reload();" >Back</a></div></div>
  <div id="btnDiv<?php echo $key;?>">
  <div class="fav_btn_fav"><a id="delbutton<?php echo $key;?>" href="javascript:;" onclick="DeleteFav(<?php echo $val['id']?>);" >Delete</a></div>
  <div class="fav_btn_fav"><a id="desbutton<?php echo $key;?>" href="javascript:;" onclick="ShowDes(<?php echo $key;?>);" >Add Desctription</a></div>
  </div>
  
  </div>
 
  <?php }?>
  <?php $i++  ?>
  <?php  if($i==4) { ?>
</div>

<?php $i=1;}  ?>

<?php } ?>

<?php } else {?>
<div><p align="center" style="font-size:16px;"> you have no favorite Images</p></div>
<?php } ?>





       
       </div>
        <div class="clear"></div>
        </div>
        
	<!--close wraper div here-->
        <div class="clear"></div>
    
	<?php include('include/footer.php'); ?>
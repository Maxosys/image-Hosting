//thanks for downloading this app 

To intstall this app please read install.txt file which is in congiguration/general_configuration folder.


you can also see our live demo on url:
 www.nanowebtechnologies.com/image_hosting/ 


-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 31, 2013 at 12:58 PM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `image_hosting`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_favourites`
--

CREATE TABLE IF NOT EXISTS `user_favourites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `IP_Address` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `imageId` varchar(500) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `width` varchar(255) NOT NULL,
  `height` varchar(255) NOT NULL,
  `tbWidth` varchar(255) NOT NULL,
  `tbHeight` varchar(255) NOT NULL,
  `unescapedUrl` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `visibleUrl` varchar(255) NOT NULL,
  `titleNoFormatting` varchar(255) NOT NULL,
  `originalContextUrl` varchar(255) NOT NULL,
  `contentNoFormatting` varchar(255) NOT NULL,
  `tbUrl` varchar(255) NOT NULL,
  `added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
